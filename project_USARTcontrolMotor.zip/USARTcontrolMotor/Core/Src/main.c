/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "can.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint8_t rx_byte; 
int direction=0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart);

void Function_For_1(void);
void Function_For_0(void);
void Function_For_m1(void);

void CAN_SendMessage(uint8_t *data);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_CAN1_Init();
  /* USER CODE BEGIN 2 */

  HAL_UART_Receive_IT(&huart1, &rx_byte, 1);
	
	
	
	
	
	
	
	if (HAL_CAN_Start(&hcan1) != HAL_OK) {
  // ����������
  Error_Handler();
}
	








  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		
		
		
		
		
		
		uint8_t num=0x0A;
		if(direction==1){
			int16_t current_value = +1000;
		
		uint8_t canData[8] = {(uint8_t)(current_value & 0xFF),(uint8_t)((current_value >> 8) & 0xFF),num,num,num,num,num};
    CAN_SendMessage(canData);
    //HAL_Delay(100);  // ÿ�뷢��һ��
		}else if(direction==-1){
		int16_t current_value = +100;
		//uint8_t num=0x0A;
		uint8_t canData[8] = {(uint8_t)(current_value & 0xFF),(uint8_t)((current_value >> 8) & 0xFF),num,num,num,num,num};
    CAN_SendMessage(canData);
    //HAL_Delay(100);  // ÿ�뷢��һ��
		}else{
		int16_t current_value = +0;
		//uint8_t num=0x0A;
		uint8_t canData[8] = {(uint8_t)(current_value & 0xFF),(uint8_t)((current_value >> 8) & 0xFF),num,num,num,num,num};
    CAN_SendMessage(canData);
    //HAL_Delay(100);  // ÿ�뷢��һ��
		}
		HAL_Delay(100);
		
		
		
		
		/*
		int16_t current_value = +1000;
		uint8_t num=0x0A;
		uint8_t canData[8] = {(uint8_t)(current_value & 0xFF),(uint8_t)((current_value >> 8) & 0xFF),num,num,num,num,num};
    CAN_SendMessage(canData);
    HAL_Delay(100);  // ÿ�뷢��һ��
		*/
		
		
		
		
		
		
		
		
		
		
		
		
    /* ??????????????????????? */
		/*
		//HAL_UART_Transmit(&huart1, (uint8_t*)"Hello 32\r\n", sizeof("Hello 32\r\n")-1, 100);
		HAL_Delay(1000);
		int temperature = 25;
		char buffer[50];
		sprintf(buffer, "Temperature: %dC\r\n", temperature);
		HAL_UART_Transmit(&huart1, (uint8_t*)buffer, strlen(buffer), 100);
		*/
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 15;
  RCC_OscInitStruct.PLL.PLLN = 216;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */









void CAN_SendMessage(uint8_t *data) {
  CAN_TxHeaderTypeDef TxHeader;
  uint32_t TxMailbox;

  // ���÷�����Ϣͷ
  TxHeader.StdId = 0x2FE;
  TxHeader.ExtId = 0;
  TxHeader.IDE = CAN_ID_STD;
  TxHeader.RTR = CAN_RTR_DATA;
  TxHeader.DLC = 8;
  TxHeader.TransmitGlobalTime = DISABLE;

  if (HAL_CAN_AddTxMessage(&hcan1, &TxHeader, data, &TxMailbox) != HAL_OK) {
    Error_Handler();
  }
}



















void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{

  if(huart->Instance == USART1)
  {

    if(rx_byte == '+')
    {
      Function_For_1(); 
    }
    else if(rx_byte == '0')
    {
      Function_For_0(); 
    }
		else if(rx_byte == '-')
		{
			Function_For_m1();
		}

  
    HAL_UART_Transmit(&huart1, &rx_byte, 1, 0xFF);

 
    HAL_UART_Receive_IT(&huart1, &rx_byte, 1);
  }
}

void Function_For_1(void)
{
  const char msg[] = "-> Received '1', executing Clockwise Rotation...\r\n";
  direction=1;
	HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), 100); 
 
}


void Function_For_0(void)
{
  const char msg[] = "-> Received '0', executing Stop...\r\n";
	direction=0;
  HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), 100); // ??????????
 
}

void Function_For_m1(void)
{
  const char msg[] = "-> Received '-1', executing Anticlockwise Rotation...\r\n";
	direction=-1;
  HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), 100); // ??????????
 
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
